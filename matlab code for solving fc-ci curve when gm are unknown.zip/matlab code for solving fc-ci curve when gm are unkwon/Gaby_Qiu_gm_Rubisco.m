function [fc] = Gaby_Qiu_gm_Rubisco(beta,ci)
% ------------transfer from RuBP limitation---------
global gm; 
a1=beta(1); Rd=beta(2);% a1=Vcmax

[a2,cp]=compute_parameters;

% ----------compute fc for Rubisco limitation-------
YY=(a1^2+2*a1*(a2-ci+2*cp)*gm-2*a1*Rd+((a2+ci)*gm+Rd).^2);
fc=(1/2)*(a1+(a2+ci)*gm-Rd-sqrt(YY));
end

