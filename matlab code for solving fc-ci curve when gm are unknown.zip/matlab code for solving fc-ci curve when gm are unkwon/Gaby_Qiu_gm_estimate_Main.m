%This program was developed to determine Vcmax, Jmax, gm,Rd and TPU
%from measured fc-ci curves when gm is unknown.
%------------------Equations used-------------
%The Farquhar photosynthesis model and cc= ci-fc/gm were used
%------------------Reference-------------------
%1.Sharkey, T. D., et al. (2007). "Fitting photosynthetic carbon dioxide 
%response curves for C3 leaves." Plant, Cell and Environment 30(9): 1035-1040.
%------------------Critical ci------------------
% A critical ci of 300 ppm was defined to delineate Rubisco
% and RuBP limitations 
% This value is recommended but can be altered
%------------------How we calculated--------
% The Vcmax and Rd were calculated from Rubisco limitation
% and Jmax and gm were calculated from RuBP limititation
%TPU from TPU limitation
%-------------------Authors---------------------
%Authors:Gabriel Katul and Rangjian Qiu
%Date :4/26/2018
%-----------------------Main inputs-------------
%fc-photosynthesis (micro-mol/m2/s)
%ci-intercell CO2 concentration (micro-mol/mol). 
%T_L- leaf temperature(oC)
% ----------------------Main outputs-----------
% Vcmax---Maximum Rubisco capacity (micro mol/m2/s).
% Jmax----Maximum electron transport rate (micro mol/m2/s)
% Rd------Mitochondrial respiration(micro mol/m2/s)
% gm------Mesophyll conductance (mol/m2/s)
% TPU-----rate of use of triose phosphates (micro mol/m2/s)
%-----------------------Tips----------------------
% To slove for many fc-cc curves,
% run Qiu_gm_estimate_Main_for_many_curves

%%%%%%%%%%%%%%%---Cite this paper---%%%%%%%%%%%%%%%%%%%%%%%
%If this code is useful, please cite 
%Qiu and Katul, 2019, Maximizing leaf carbon gain in varying saline conditions: 
%An optimization model with dynamic mesophyll conductance, 
%The Plant Journal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------------------main program----------------
clear all
clc
%------------------read data----------------------
%fc	    ci	Tleaf (this is the data from the fc-ci curve) 
%1      2     3
global T_L;
A=load('0000.txt');
fc=A(:,1);            % photosynthesis
ci=A(:,2);            % intercellular CO2
T_L=mean(A(:,3));     % leaf temperature
%-------The actual fitting is conducted here
[Jmax,gm,Vcmax,Rd,MSE_total,TPU] = fc_ci_fit_gm(ci,fc);
fc_TPU=3*TPU-Rd;
%-------Plot Figure 1 to show how the model fits the data---
figure(1)
clf
cc=ci-fc/gm; 
%------------- Plot the initical fc-cc curve---------------
plot (cc, fc,'bo','MarkerFaceColor','b','linewidth',2)
hold on
%-------------Plot Rubisco limited data-----------------
ci=[20:1:1400]';
beta_L=[Vcmax Rd];
[fc_Rub] = Gaby_Qiu_gm_Rubisco(beta_L,ci);
cc_Rub=ci-fc_Rub./gm;
plot (cc_Rub, fc_Rub,'-','Color',[0.9 0.1 0.1],'linewidth',3)
hold on
%---------------Plot RuBP limited data------------------
beta_L=[Jmax/4 gm];
[fc_RuBP] = Gaby_Qiu_gm_RuBP(beta_L,ci);
cc_RuBP=ci-fc_RuBP./gm;
plot (cc_RuBP, fc_RuBP,'-','Color',[0.07 0.6 0.26],'linewidth',3)
%---------------Plot TPU limited data---------------------
line([600,1400],[fc_TPU,fc_TPU],'LineStyle','-.','color','m','linewidth',3)
%--------
xlabel ('{\it C_{c}} (\mu mol mol^{-1})','fontweight','bold','fontsize',12)
ylabel ('{\it{f_c}} (\mu mol m^{-2} s^{-1})','fontweight','bold','fontsize',12')
axis([0,1400,-10,60])
legend('Data','Rubisco ','RuBP','TPU','location','southeast')
