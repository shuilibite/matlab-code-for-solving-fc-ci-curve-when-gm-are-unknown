%-----------------------------------------------------------------
%[Jmax,gm, Vcmax, Rd,MSE_total,TPU] = fc_ci_fit_gm(ci,fc) computes 
%the parameters of the photosynthesis curve for C3 plants using
%measured fc-ci curve.  The approach returns Jmax, gm, Vcmax, and
%Rd.  Nlinfit is used in Matlab.
%The model requires ci_crit to delineate between Rubisco and 
%RuBP limitations on fc (set to 300 ppm here).
%-----------------------------------------------------------------
function [Jmax,gm, Vcmax, Rd,MSE_total,TPU] = fc_ci_fit_gm(ci,fc)
global Rd
global gm
%------define the critical ci, can bed modified here----
ci_crit=300;  
%------find the TPU limitation-------------------------
TPUo=fc./max(fc);
TPUt=find(TPUo>0.98); 
fc_TPU=fc(min(TPUt));
ci_TPU=min(ci(TPUt));
%---------------------------------------------------
opts=statset('MaxIter',600,'TolX',1e-9);
%-----assign the initial Rd between 1-10, not sensitive to the final results
Rd=2;          
%----- first run the RuBP limitation to calculate gm and Jmax/4
x=ci(ci>ci_crit & ci<ci_TPU); 
y=fc(ci>ci_crit & ci<ci_TPU);
beta0=[50 0.05]; % initial values for a1_RuBP(Jmax/4)and gm
beta=nlinfit(x,y,@Gaby_Qiu_gm_RuBP,beta0,opts);
a1_RuBP=beta(1); %a1_RuBP=Jmax/4
gm_RuBP=beta(2);
gm=gm_RuBP;      % transfer gm to Rubisco limitation
% -----Then run the Rubisco limitation to calculate Vcmax and Rd
x=ci(ci<ci_crit);
y=fc(ci<ci_crit);
beta0=[50 1];    % initial values for a1_Rub (Vcmax) and Rd
[beta,R,J,CovB,MSE]=nlinfit(x,y,@Gaby_Qiu_gm_Rubisco,beta0,opts);
a1_Rub=beta(1);  % a1_Rub=Vcmax
Rd_Rub=beta(2);
Rd_error=99999999;
cnt=0;
%--------rerun the model for minimun the Rd differences---
while Rd_error > 1e-6 && cnt < 200
   cnt=cnt+1;
   Rd=Rd_Rub;
   x=ci(ci>ci_crit & ci<ci_TPU);
   y=fc(ci>ci_crit & ci<ci_TPU);
   beta0=[50 0.05];
   [beta,R,J,CovB,MSE]=nlinfit(x,y,@Gaby_Qiu_gm_RuBP,beta0,opts);
   a1_RuBP=beta(1);
   gm_RuBP=beta(2);
   gm=gm_RuBP;
   MSE1=MSE;
%---------------------------------------------------
   x=ci(ci<ci_crit);
   y=fc(ci<ci_crit);
   beta0=[50 1];
   [beta,R,J,CovB,MSE]=nlinfit(x,y,@Gaby_Qiu_gm_Rubisco,beta0,opts);
   a1_Rub=beta(1);
   Rd_Rub=beta(2);
   MSE2=MSE;
   Rd_error=abs(Rd-Rd_Rub);
end 
%-------output of Vcmax and Jmax and TPU-------------
Vcmax=a1_Rub;
Jmax=4*a1_RuBP;
MSE_total=MSE1+MSE2; % total mean squre root
TPU=(fc_TPU+Rd_Rub)/3;
end

