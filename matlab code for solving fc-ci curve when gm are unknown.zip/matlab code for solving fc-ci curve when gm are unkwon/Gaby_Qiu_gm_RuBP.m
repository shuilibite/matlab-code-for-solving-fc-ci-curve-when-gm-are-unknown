function [fc] = Gaby_Qiu_gm_RuBP(beta,ci)
%---------transfer from Rubisco limitation----------
global Rd   
a1=beta(1);gm=beta(2);% a1=Jmax/4

[a2, cp]= compute_parameters;
a2_RuBP=2*cp;YY=[];
%------ compute fc for RuBP limitation-------------
YY=(a1^2+2*a1*(a2_RuBP-ci+2*cp)*gm-2*a1*Rd+((a2_RuBP+ci)*gm+Rd).^2);
fc=(1/2)*(a1+(a2_RuBP+ci)*gm-Rd-sqrt(YY));

end