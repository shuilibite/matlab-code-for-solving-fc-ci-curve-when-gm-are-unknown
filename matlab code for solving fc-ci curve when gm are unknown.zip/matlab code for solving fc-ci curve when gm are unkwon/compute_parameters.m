%-----------------------------------------------------------------
%[a2,cp] = compute_parameters adjusts parameters a2 and the 
%compensation point with temperature using standard equations
%taken from Sharkey et al. (2007)
%-----------------------------------------------------------------
function [a2,cp] = compute_parameters
global T_L;
%------These constants are taken from Sharkey et. al (2007)------
%------ Rubisco limited photosynthesis parameters ----------------
c_Kc=35.9774;    %scaling constant for Kc
Ha_Kc=80.99;     %enthalpies of activation for Kc
c_Ko=12.3772;    %scaling constant for Ko
Ha_Ko=23.72;     %enthalpies of activation for Ko
c_cp=11.187;     %scaling constant for cp
Ha_cp=24.46;     %enthalpies of activation for cp
Kc=(exp(c_Kc-(Ha_Kc/(0.008314*(273.15+T_L)))))*101/10; %umol/mol
Ko=(exp(c_Ko-(Ha_Ko/(0.008314*(273.15+T_L)))))*101/10; %mmol/mol
cp=(exp(c_cp-(Ha_cp/(0.008314*(273.15+T_L)))))*101/10; %umol/mol

Coa=210;          %mmol/mol
a2=Kc*(1+Coa/Ko); %umol/mol

end

