%---------------------Steps-----------------------------
%----Four steps below are intended to guide running multiple 
%    fc-ci curves
%----1.input data organized as follows (3 columns)
%----fc 	ci	 T_leaf
%----2.save file names as ****.txt
%----for example file name as 0001.txt,0002.txt each contain an 
%    fc-ci curve to be analyzed
%----3.order the fc-ci curves in fc_ci_filelist.txt (in the same folder)
%----4.modify the number of your fc-ci files in main program below(Nfile)
%---------------------Output-----------------------------------
%----output of files are organized as 
%----Vcmax gm Jmax Rd TPU for each fc-ci curves
%----can be find in 'Optimized_Parameters.txt' in the folder

%%%%%%%%%%%%%%%---Cite this paper---%%%%%%%%%%%%%%%%%%%%%%%
%If this code is useful, please cite 
%Qiu and Katul, 2019, Maximizing leaf carbon gain in varying saline conditions: 
%An optimization model with dynamic mesophyll conductance, 
%The Plant Journal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%---------------------Main progarm-----------------------------------
clear all
clc
Nfiles=3;                          %Number of fc-ci files to analyze
fid = fopen('fc_ci_filelist.txt'); %opens the directory file and gives it ID called fid
%---tips: you need a fc_ci_filelist.txt file in the directory for all fc_ci curves  to define 
%---the order of the fc_ci curves (see our example in the directory)
%---scan the files - in our example, names have 8 characters including '.txt'
A1=fscanf(fid,'%1s',[8,Nfiles]); 
s=[];                              %this matrix will be used to store output
%Reads N rows by 9 columns (characters)into array A1
for ii=1:Nfiles
   firstchar=(ii-1)*8+1;% if your files name have 4 characters, just change 8 to 4
   lastchar=ii*8;       % if your files name have 4 characters, just change 8 to 4
   B=A1(firstchar:lastchar);
%------------- read data-------------
%Photo	Ci	Tleaf	
%1      2       3      
A=load(B);
global T_L; %% leaf temperature
%---- read temperature, photosynthesis, ci---------
T_L=mean(A(:,3));
fc=A(:,1);%% photosynthesis
ci=A(:,2);%% intercellular CO2
%-----------------------
[Jmax,gm,Vcmax,Rd,MSE_total,TPU] = fc_ci_fit_gm(ci,fc);
%------ store optimized results in matrix s (Vcmax, Rd, Jmax, gm, TPU.)
s=[s; T_L Vcmax gm Jmax Rd TPU];
end
%Send all the results stored in s to file name 'Optimized_Parameters.txt as ascii'
header={'T_L', 'Vcmax', 'gm', 'Jmax', 'Rd', 'TPU'};
s2=num2cell(s);
xlswrite('Optimized_Parameters.xlsx', [header;s2], 'sheet1')
